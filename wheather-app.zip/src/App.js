import './App.css';
import WeatherApp from './WeatherApp/weatherApp';

function App() {
  return (
    <div className="App">
      <WeatherApp />
    </div>
  );
}

export default App;
